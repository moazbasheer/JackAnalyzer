import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class CompilationEngine {
	private JackTokenizer tokenizer;
	private File file;
	private FileWriter output;
	private String indentation;
	CompilationEngine(String filename)
			throws IOException {
		file = new File(filename);
		output = new FileWriter(file);
		System.out.println(filename);
		tokenizer = new JackTokenizer(filename.split("[.]")[0] + ".jack");
		indentation = "";
	}

	void compileClass() throws IOException {
		tokenizer.advance();
		if (tokenizer.tokenType() == Constants.KEYWORD
				&& tokenizer.keyword() == Constants.CLASS) {
			output.write(indentation + "<class>\n");
			indentation += "\t";   // increase indentation
			output.write(indentation + "<keyword> class </keyword>\n");
			
			tokenizer.advance();
			if (tokenizer.tokenType() == Constants.IDENTIFIER) {
				output.write(this.indentation + tokenizer.getTag() + "\n");
            } else {
                System.out.println("Error in class name");
                return;
            }
			
			tokenizer.advance();
			if (tokenizer.tokenType() == Constants.SYMBOL) {
				output.write(indentation + tokenizer.getTag() + "\n");
            } else {
            	System.out.println(tokenizer.getToken() + " " + tokenizer.tokenType());
                System.out.println("Error in bracket of class");
                return;
            }
			tokenizer.advance();
			compileClassVariables();
			compileMethods();
			indentation = indentation.substring(0, indentation.length() - 1);  
											// decrease indentation
			output.write(indentation + "</class>\n");
		}else {
			System.out.println("There's Error\n");
			return ;
		}
	}
	private void compileMethods() throws IOException{
		
		
		while(tokenizer.keyword() == Constants.FUNCTION
				|| tokenizer.keyword() == Constants.METHOD
				|| tokenizer.keyword() == Constants.CONSTRUCTOR){
			output.write(indentation + "<subroutineDec>\n");
			indentation += "\t";
			
			// header of function
			output.write(indentation + tokenizer.getTag() + "\n");
			tokenizer.advance();
			if(tokenizer.tokenType() == Constants.IDENTIFIER
					|| tokenizer.tokenType() == Constants.KEYWORD){
				output.write(indentation + tokenizer.getTag() + "\n");
				tokenizer.advance();
			}else{
				System.out.println(tokenizer.tokenType() + " " + tokenizer.keyword());
				System.out.println("Error invalid function return type");
				return ;
			}
			if(tokenizer.tokenType() == Constants.IDENTIFIER){
				output.write(indentation + tokenizer.getTag() + "\n");
				tokenizer.advance();
			}else{
				System.out.println("Error invalid function name");
				return ;
			}
			if(tokenizer.tokenType() == Constants.SYMBOL){
				output.write(indentation + tokenizer.getTag() + "\n");
				tokenizer.advance();
			}else{
				System.out.println("Error ,there's no symbol (");
				return ;
			}
			// parameters of function
			output.write(indentation + "<parameterList>\n");
			indentation += "\t";
			while(tokenizer.tokenType() == Constants.IDENTIFIER
				|| tokenizer.tokenType() == Constants.KEYWORD){
				output.write(indentation + tokenizer.getTag() + "\n");
				tokenizer.advance();
				if(tokenizer.tokenType() == Constants.IDENTIFIER){
					output.write(indentation + tokenizer.getTag() + "\n");
					tokenizer.advance();
				}else{
					System.out.println("Error invalid parameter");
					return ;
				}
				if(tokenizer.tokenType() == Constants.SYMBOL){
					if(tokenizer.symbol().equals(")")){
						break;
					}
					output.write(indentation + tokenizer.getTag() + "\n");
					tokenizer.advance();
				}else{
					System.out.println("Error invalid parameter");
					return ;
				}
			}
			indentation = indentation.substring(0,indentation.length() - 1);
			output.write(indentation + "</parameterList>\n");
			output.write(indentation + tokenizer.getTag() + "\n");// ) symbol
			tokenizer.advance();
			output.write(indentation + "<subroutineBody>\n");
			indentation += "\t";
			output.write(indentation + tokenizer.getTag() + "\n"); // { symbol
			tokenizer.advance();
			System.out.println(tokenizer.keyword());
			compileVarDecs();
			compileStatements();
			indentation = indentation.substring(0,indentation.length() - 1);
			output.write(indentation + "</subroutineBody>\n");
			indentation = indentation.substring(0,indentation.length() - 1);
			output.write(indentation + "</subroutineDec>\n");
		}
		System.out.println("Error, there is no function" + tokenizer.keyword());
	}
	void compileVarDecs() throws IOException{
		while(tokenizer.keyword() == Constants.VAR){
			output.write(indentation + "<varDec>\n");
			indentation += "\t";
			output.write(indentation + tokenizer.getTag() + "\n");
			tokenizer.advance();
			if(tokenizer.keyword() == Constants.CHAR
			|| tokenizer.keyword() == Constants.BOOLEAN
			|| tokenizer.tokenType() == Constants.IDENTIFIER
			|| tokenizer.keyword() == Constants.INT){
				output.write(indentation + tokenizer.getTag() + "\n");
				tokenizer.advance();
			}else{
				System.out.println(tokenizer.keyword() + " " + tokenizer.getToken());
				System.out.println("Error in the datatype inside function");
				return ;
			}
			if(tokenizer.tokenType() == Constants.IDENTIFIER){
				output.write(indentation + tokenizer.getTag() + "\n");
				tokenizer.advance();
			}else{
				System.out.println("Error in the name of a function");
				return ;
			}
			if(tokenizer.tokenType() == Constants.SYMBOL){
				output.write(indentation + tokenizer.getTag() + "\n");
				tokenizer.advance();
			}else{
				System.out.println("Error in the semicolon inside function");
				return ;
			}
			indentation = indentation.substring(0, indentation.length() - 1);
			output.write(indentation + "</varDec>\n");
		}
	}
	void compileStatements() throws IOException{
		
		output.write(indentation + "<statements>\n");
		indentation += "\t";
		while(tokenizer.keyword() == Constants.RETURN
		|| tokenizer.keyword() == Constants.DO
		|| tokenizer.keyword() == Constants.LET
		|| tokenizer.keyword() == Constants.IF
		|| tokenizer.keyword() == Constants.WHILE){
			output.write(indentation + tokenizer.getTag() + "\n");
			if(tokenizer.keyword() == Constants.RETURN){
				System.out.println("Return Statement");
				return ;
			}else if(tokenizer.keyword() == Constants.DO){
				System.out.println("Do Statement");
				return ;
			}else if(tokenizer.keyword() == Constants.LET){
				System.out.println("let Statement");
				return ;
			}else if(tokenizer.keyword() == Constants.IF){
				System.out.println("let Statement");
				return ;
			}else if(tokenizer.keyword() == Constants.WHILE){
				System.out.println("While Statement");
				return ;
			}else {
				System.out.println("Invalid statement");
				return ;
			}
			//tokenizer.advance();
		}
		
		System.out.println("Error, invalid statement keyword");
		
		
		indentation = indentation.substring(0,indentation.length() - 1);
		output.write(indentation + "</statements>\n");
	}
	void compileClassVariables() throws IOException{
		
		while(tokenizer.keyword() == Constants.STATIC
				|| tokenizer.keyword() == Constants.FIELD){
			output.write(indentation + "<classVarDec>\n");
			indentation += "\t";
			output.write(indentation + tokenizer.getTag() + "\n");
			tokenizer.advance();
			if (tokenizer.keyword() == Constants.BOOLEAN 
					|| tokenizer.keyword() == Constants.INT 
					|| tokenizer.keyword() == Constants.CHAR
					|| tokenizer.tokenType() == Constants.IDENTIFIER) {
				output.write(indentation + tokenizer.getTag() + "\n");
            } else {
                System.out.println("ERROR in data type");
                return;
            }
			tokenizer.advance();
			if (tokenizer.tokenType() == Constants.IDENTIFIER) {
				output.write(indentation + tokenizer.getTag() + "\n");
            } else {
                System.out.println("ERROR in variable name");
                return;
            }
			tokenizer.advance(); // handling ; and ,
			while (tokenizer.tokenType() == Constants.SYMBOL) {
				if(tokenizer.getToken().equals(";")){
					output.write(indentation + tokenizer.getTag() + "\n");
					tokenizer.advance();
					break;
				}else if(tokenizer.getToken().equals(",")){
					output.write(indentation + tokenizer.getTag() + "\n");
					tokenizer.advance();
					if(tokenizer.tokenType() == Constants.IDENTIFIER){
						output.write(indentation + tokenizer.getTag() + "\n");
					}else{
						System.out.println("ERROR in variable name");
						return;
					}
				}
				else {
	                System.out.println("ERROR in semicolon");
	                return;
				}
				tokenizer.advance();
            }    
			
			indentation = indentation.substring(0, indentation.length() - 1);
			output.write(indentation + "</classVarDec>\n");
		}
		
	}
	void close() throws IOException{
		tokenizer.close();
		output.close();
	}
}
